# Matibatidos POS — APK RC1

Proyecto Android para empaquetar `app/src/main/assets/index.html` (Matibatidos POS APK RC1).

## Compilación en GitHub Actions
1. Sube todo este proyecto a un repositorio de GitHub.
2. Ve a **Actions** → **Build Matibatidos POS APK** → **Run workflow**.
3. Al terminar, abre los **Artifacts** y descarga `Matibatidos-POS-debug`.

## Puentes Android incluidos
- `AndroidPrinter.selectPrinter()` — selecciona un dispositivo Bluetooth previamente vinculado.
- `AndroidPrinter.printReceipt()` — envía un ticket ESC/POS por Bluetooth SPP.
- `AndroidBackup.sendBackup()` — POST HTTPS del respaldo al Web App configurado.
- `AndroidFileSaver.saveBase64File()` — guarda archivos en `Downloads/Matibatidos`.

La versión RC1 conserva el HTML y sus funciones; el proyecto añade la capa Android necesaria para la APK.
