package com.matibatidos.pos;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient.FileChooserParams;
import android.widget.Toast;

import android.content.ContentValues;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private SharedPreferences prefs;
    private static final int REQ_BT = 7001;
    private static final int REQ_FILE_CHOOSER = 7002;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private ValueCallback<Uri[]> fileChooserCallback;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("matibatidos_apk", MODE_PRIVATE);
        requestBluetoothPermissions();
        setupWebView();
    }

    private void requestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            List<String> needed = new ArrayList<>();
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.BLUETOOTH_CONNECT);
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.BLUETOOTH_SCAN);
            if (!needed.isEmpty()) requestPermissions(needed.toArray(new String[0]), REQ_BT);
        }
    }

    private void setupWebView() {
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(intent, REQ_FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    fileChooserCallback = null;
                    Toast.makeText(MainActivity.this, "No se pudo abrir el selector de archivos", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new AndroidPrinterBridge(this), "AndroidPrinter");
        webView.addJavascriptInterface(new AndroidBackupBridge(this), "AndroidBackup");
        webView.addJavascriptInterface(new AndroidFileSaverBridge(this), "AndroidFileSaver");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE_CHOOSER) {
            if (fileChooserCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK) {
                if (data != null && data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i=0;i<count;i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data != null && data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            fileChooserCallback.onReceiveValue(results);
            fileChooserCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public class AndroidPrinterBridge {
        private final Context context;
        AndroidPrinterBridge(Context c) { context = c; }

        @JavascriptInterface public String getStatus() {
            try {
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null) return "{\"ok\":false,\"enabled\":false,\"error\":\"Bluetooth no disponible\"}";
                boolean enabled = adapter.isEnabled();
                int count = 0;
                if (enabled && (Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)) count = adapter.getBondedDevices().size();
                return "{\"ok\":true,\"enabled\":"+enabled+",\"bonded\":"+count+"}";
            } catch(Exception e) { return json(false,e.getMessage()); }
        }

        @JavascriptInterface public String openBluetoothSettings() {
            try {
                startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS));
                return "{\"ok\":true}";
            } catch(Exception e) { return json(false,e.getMessage()); }
        }

        @JavascriptInterface public String selectPrinter() {
            try {
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null) return json(false, "Bluetooth no disponible");
                if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread(() -> requestBluetoothPermissions());
                    return json(false, "Permiso Bluetooth requerido. Concede el permiso y vuelve a pulsar el botón.");
                }
                if (!adapter.isEnabled()) {
                    runOnUiThread(() -> {
                        try { startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)); }
                        catch(Exception ignored){ startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)); }
                    });
                    return json(false, "Bluetooth está apagado. Actívalo y vuelve a seleccionar la impresora.");
                }
                List<BluetoothDevice> devices = new ArrayList<>(adapter.getBondedDevices());
                if (devices.isEmpty()) {
                    runOnUiThread(() -> {
                        new AlertDialog.Builder(MainActivity.this)
                            .setTitle("No hay dispositivos vinculados")
                            .setMessage("Primero vincula la impresora desde Ajustes > Bluetooth y luego vuelve a Matibatidos POS.")
                            .setPositiveButton("Abrir Bluetooth", (d,w) -> startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)))
                            .setNegativeButton("Cancelar", null).show();
                    });
                    return json(false, "No hay impresoras Bluetooth vinculadas");
                }
                String[] labels = new String[devices.size()];
                for (int i=0;i<devices.size();i++) {
                    BluetoothDevice d=devices.get(i);
                    labels[i]=(d.getName()==null?"Dispositivo":d.getName())+"\n"+d.getAddress();
                }
                final BluetoothDevice[] selected = new BluetoothDevice[1];
                final CountDownLatch latch = new CountDownLatch(1);
                runOnUiThread(() -> new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Seleccionar impresora Bluetooth")
                    .setSingleChoiceItems(labels, -1, (dialog, which) -> {
                        selected[0]=devices.get(which);
                        prefs.edit().putString("printer_name", selected[0].getName()).putString("printer_address", selected[0].getAddress()).apply();
                        dialog.dismiss(); latch.countDown();
                    }).setNegativeButton("Cancelar", (dialog, which) -> latch.countDown()).setOnCancelListener(d -> latch.countDown()).show());
                latch.await();
                if(selected[0]!=null) return "{\"ok\":true,\"name\":\""+escJson(selected[0].getName())+"\",\"address\":\""+escJson(selected[0].getAddress())+"\"}";
                return json(false, "Selección cancelada");
            } catch(Exception e) { return json(false,e.getMessage()); }
        }

        @JavascriptInterface public String testConnection() {
            try {
                String address=prefs.getString("printer_address","");
                if(address.isEmpty()) return json(false,"No hay impresora seleccionada");
                BluetoothAdapter adapter=BluetoothAdapter.getDefaultAdapter();
                if(adapter==null||!adapter.isEnabled()) return json(false,"Bluetooth está apagado");
                if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return json(false,"Permiso Bluetooth requerido");
                BluetoothDevice device=adapter.getRemoteDevice(address);
                adapter.cancelDiscovery();
                BluetoothSocket socket=null;
                try {
                    socket=device.createRfcommSocketToServiceRecord(SPP_UUID);
                    socket.connect();
                } catch(Exception first) {
                    try { if(socket!=null) socket.close(); } catch(Exception ignored){}
                    java.lang.reflect.Method m=device.getClass().getMethod("createRfcommSocket", int.class);
                    socket=(BluetoothSocket)m.invoke(device,1);
                    socket.connect();
                } finally { try{if(socket!=null)socket.close();}catch(Exception ignored){} }
                return json(true,"Conexión Bluetooth correcta");
            } catch(Exception e) { return json(false,"No se pudo conectar: "+e.getMessage()); }
        }

        @JavascriptInterface public String printReceipt(String saleJson) {
            try {
                String address=prefs.getString("printer_address","");
                if(address.isEmpty()) return json(false,"No hay impresora Bluetooth seleccionada");
                if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return json(false,"Permiso Bluetooth requerido");
                BluetoothAdapter adapter=BluetoothAdapter.getDefaultAdapter();
                if(adapter==null||!adapter.isEnabled()) return json(false,"Bluetooth está apagado");
                BluetoothDevice device=adapter.getRemoteDevice(address);
                final String payload=buildEscPosReceipt(new JSONObject(saleJson));
                Future<Boolean> f=Executors.newSingleThreadExecutor().submit((Callable<Boolean>)() -> {
                    BluetoothSocket socket=null;
                    try {
                        adapter.cancelDiscovery();
                        try { socket=device.createRfcommSocketToServiceRecord(SPP_UUID); socket.connect(); }
                        catch(Exception first){ try{if(socket!=null)socket.close();}catch(Exception ignored){} java.lang.reflect.Method m=device.getClass().getMethod("createRfcommSocket",int.class); socket=(BluetoothSocket)m.invoke(device,1); socket.connect(); }
                        OutputStream out=socket.getOutputStream();
                        out.write(payload.getBytes(StandardCharsets.UTF_8));
                        out.write(new byte[]{0x1D,0x56,0x41,0x03}); out.flush(); return true;
                    } finally { try { if(socket!=null) socket.close(); } catch(Exception ignored){} }
                });
                boolean ok=f.get();
                return json(ok,ok?"Impresión enviada":"No se pudo imprimir");
            } catch(Exception e) { return json(false,e.getMessage()); }
        }
    }

    private String buildEscPosReceipt(JSONObject s) throws Exception {
        StringBuilder b=new StringBuilder(); b.append("\u001B@\u001B\u0061\u0001"); b.append("MATIBATIDOS\n"); b.append("FACTURA ").append(s.optString("invoice","")).append("\n"); b.append("--------------------------------\n");
        JSONArray items=s.optJSONArray("items"); if(items!=null) for(int i=0;i<items.length();i++){JSONObject x=items.getJSONObject(i);b.append(x.optInt("qty",1)).append(" x ").append(x.optString("name","")).append("  ").append(money(x.optDouble("price",0)*x.optInt("qty",1))).append("\n");}
        b.append("--------------------------------\n"); b.append("Subtotal: ").append(money(s.optDouble("subtotal",0))).append("\n"); b.append("Descuento: ").append(money(s.optDouble("discount",0))).append("\n"); b.append("TOTAL: ").append(money(s.optDouble("total",0))).append("\n"); b.append("Pago: ").append(s.optString("pay","")).append("\n"); if("Efectivo".equals(s.optString("pay", ""))){b.append("Recibido: ").append(money(s.optDouble("cashReceived",0))).append("\n");b.append("Cambio: ").append(money(s.optDouble("change",0))).append("\n");} b.append("\nGracias por visitarnos\n\n"); return b.toString();
    }
    private String money(double v){ return String.format(java.util.Locale.US,"C$ %.2f",v); }
    private String json(boolean ok,String msg){ return "{\"ok\":"+ok+",\"error\":\""+escJson(msg==null?"":msg)+"\"}"; }
    private String escJson(String s){ return (s==null?"":s).replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n"); }

    public class AndroidBackupBridge {
        private final Context context; AndroidBackupBridge(Context c){context=c;}
        @JavascriptInterface public String sendBackup(String url, String body) {
            try { Future<String> f=Executors.newSingleThreadExecutor().submit(() -> {HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(url).openConnection();c.setRequestMethod("POST");c.setConnectTimeout(15000);c.setReadTimeout(30000);c.setDoOutput(true);c.setRequestProperty("Content-Type","text/plain;charset=UTF-8");try(OutputStream out=c.getOutputStream()){out.write(body.getBytes(StandardCharsets.UTF_8));}int code=c.getResponseCode();return code>=200&&code<300?"{\"ok\":true}":json(false,"HTTP "+code);}finally{if(c!=null)c.disconnect();}});return f.get(); } catch(Exception e){return json(false,e.getMessage());}
        }
    }

    public class AndroidFileSaverBridge {
        private final Context context; AndroidFileSaverBridge(Context c){context=c;}
        @JavascriptInterface public String saveBase64File(String filename,String mimeType,String base64Data){
            try{
                byte[] bytes=Base64.decode(base64Data,Base64.DEFAULT);
                if(Build.VERSION.SDK_INT>=29){
                    ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,filename);v.put(MediaStore.Downloads.MIME_TYPE,mimeType);v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/Matibatidos");v.put(MediaStore.Downloads.IS_PENDING,1);
                    Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(uri==null)return json(false,"No se pudo crear el archivo");
                    try(OutputStream out=getContentResolver().openOutputStream(uri)){out.write(bytes);} ContentValues done=new ContentValues();done.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(uri,done,null,null);return "{\"ok\":true,\"uri\":\""+escJson(uri.toString())+"\"}";
                }
                return json(false,"La versión de Android no permite guardar directamente en Descargas con este método");
            }catch(Exception e){return json(false,e.getMessage());}
        }
    }
}
