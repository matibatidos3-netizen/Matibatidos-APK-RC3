# Matibatidos POS: no custom shrinking rules required for the first APK build.
